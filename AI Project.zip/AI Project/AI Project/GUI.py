import tkinter as tk
from tkinter import messagebox
import joblib
import numpy as np
from PIL import Image, ImageTk
import re

# Load the model and vectorizer
model = joblib.load('phishing_model.pkl')
vectorizer = joblib.load('vectorizer.pkl')

def is_valid_url(url):
    # Basic URL validation
    regex = re.compile(
        r'^(?:http|ftp)s?://'  # http:// or https://
        r'(?:(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\.)+(?:[A-Z]{2,6}\.?|[A-Z0-9-]{2,}\.?)|'  # domain...
        r'localhost|'  # localhost...
        r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}|'  # ...or ipv4
        r'\[?[A-F0-9]*:[A-F0-9:]+\]?)'  # ...or ipv6
        r'(?::\d+)?'  # optional port
        r'(?:/?|[/?]\S+)$', re.IGNORECASE)
    return re.match(regex, url) is not None

def check_url():
    url = url_entry.get()
    if not url:
        messagebox.showwarning("Input Error", "Please enter a URL")
        return

    url_features = vectorizer.transform([url])
    prediction = model.predict(url_features)[0]
    if prediction == 1:
        result_label.config(text="Phishing URL", fg="red")
    else:
        result_label.config(text="Legitimate URL", fg="green")

def clear_input():
    url_entry.delete(0, tk.END)
    result_label.config(text="")

def minimize_window():
    window.iconify()

def close_window():
    window.quit()

# Create the main window
window = tk.Tk()
window.title("AI-Enhanced Phishing Attack Detection")
window.attributes('-fullscreen', True)

# Load and display the background image
bg_image = Image.open("bg.jpg")  # Ensure the background file is in the same directory or provide the correct path
bg_image = bg_image.resize((window.winfo_screenwidth(), window.winfo_screenheight()), Image.Resampling.LANCZOS)
bg_img = ImageTk.PhotoImage(bg_image)

# Create a Canvas widget and set the background image
canvas = tk.Canvas(window, width=window.winfo_screenwidth(), height=window.winfo_screenheight())
canvas.pack(fill="both", expand=True)
canvas.create_image(0, 0, image=bg_img, anchor="nw")

# Add Minimize and Close Buttons
minimize_button = tk.Button(window, text="_", command=minimize_window, font=("Arial", 14), bg='#FFC107', padx=5, pady=5)
minimize_button_window = canvas.create_window(window.winfo_screenwidth() - 70, 10, anchor="ne", window=minimize_button)

close_button = tk.Button(window, text="X", command=close_window, font=("Arial", 14), bg='#F44336', padx=5, pady=5)
close_button_window = canvas.create_window(window.winfo_screenwidth() - 30, 10, anchor="ne", window=close_button)

# Load and display the logo
logo = Image.open("logo.png")  # Ensure the logo file is in the same directory or provide the correct path
logo = logo.resize((200, 200), Image.Resampling.LANCZOS)
logo_img = ImageTk.PhotoImage(logo)
canvas.create_image(window.winfo_screenwidth() // 2, 100, image=logo_img, anchor="n")

# Project title and team members
canvas.create_text(window.winfo_screenwidth() // 2, 320, text="\nAI-Enhanced Phishing Attack Detection", font=("Arial", 24, "bold"), fill="black")
# URL Entry
canvas.create_text(window.winfo_screenwidth() // 2, 410, text="Enter URL:", font=("Arial", 14), fill="black")
url_entry = tk.Entry(window, width=50, font=("Arial", 14))
url_entry_window = canvas.create_window(window.winfo_screenwidth() // 2, 440, anchor="n", window=url_entry)

# Buttons Frame
buttons_frame = tk.Frame(window)  # Set background to transparent
buttons_frame_window = canvas.create_window(window.winfo_screenwidth() // 2, 500, anchor="n", window=buttons_frame)

# Check Button
check_button = tk.Button(buttons_frame, text="Check URL", command=check_url, font=("Arial", 14), bg='#4CAF50', padx=10)
check_button.grid(row=0, column=0, padx=10)

# Clear Button
clear_button = tk.Button(buttons_frame, text="Clear", command=clear_input, font=("Arial", 14), bg='#FFC107', padx=10)
clear_button.grid(row=0, column=1, padx=10)

# Exit Button
exit_button = tk.Button(buttons_frame, text="Exit", command=close_window, font=("Arial", 14), bg='#F44336', padx=10)
exit_button.grid(row=0, column=2, padx=10)

# Result Label
result_label = tk.Label(window, text="", font=("Arial", 16))  # Set background to transparent
result_label_window = canvas.create_window(window.winfo_screenwidth() // 2, 570, anchor="n", window=result_label)

# Run the application
window.mainloop()
